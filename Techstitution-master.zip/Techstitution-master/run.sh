#!/usr/bin/env bash
source ./venv/bin/activate
python run.py
